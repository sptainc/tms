<?php

namespace Encore\Admin\Form\Field;

use Encore\Admin\Form\Field;

class Hidden extends Field
{
}

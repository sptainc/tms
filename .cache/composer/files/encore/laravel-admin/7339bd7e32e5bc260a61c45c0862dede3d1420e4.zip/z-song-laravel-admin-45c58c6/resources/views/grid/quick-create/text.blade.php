<div class="input-group input-group-sm">
    <input {!! $attributes !!} placeholder="{{ $label }}"/>
</div>